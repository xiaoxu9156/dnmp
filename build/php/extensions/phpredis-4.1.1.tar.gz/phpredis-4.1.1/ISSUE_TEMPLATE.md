### Expected behaviour

### Actual behaviour

### I'm seeing this behaviour on
- OS: 
- Redis:
- PHP:
- phpredis:

### Steps to reproduce, backtrace or example script

### I've checked
- [ ] There is no similar issue from other users
- [ ] Issue isn't fixed in `develop` branch
